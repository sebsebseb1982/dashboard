#ifndef QUOTE_OF_THE_DAY_H
#define QUOTE_OF_THE_DAY_H

struct QuoteOfTheDay {
  String quote;
  String author;
};

class QuoteOfTheDayService {
public:
  GFX();
  GFX(GxEPD2_3C<GxEPD2_750c_Z90, 264> *display);
  void drawCentreString(const String &buf, int x, int y);
private:
  GxEPD2_3C<GxEPD2_750c_Z90, 264> *display;
};

#endif