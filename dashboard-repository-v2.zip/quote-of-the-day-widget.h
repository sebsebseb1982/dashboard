#ifndef QUOTE_OF_THE_DAY_WIDGET_H
#define QUOTE_OF_THE_DAY_WIDGET_H

class QuoteOfTheDayWidget {
public:
  void draw();
private:

};

#endif